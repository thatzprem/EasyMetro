//
//  Junction.m
//  EasyMetro
//
//  Created by Prem kumar on 18/09/14.
//  Copyright (c) 2014 ThoughtWorks. All rights reserved.
//

#import "Junction.h"


@implementation Junction

@dynamic cityName;
@dynamic lane1;
@dynamic lane2;

@end
