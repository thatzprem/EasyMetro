//
//  EMViewModel.m
//  EasyMetro
//
//  Created by Prem kumar on 20/09/14.
//  Copyright (c) 2014 ThoughtWorks. All rights reserved.
//

#import "EMViewModel.h"

@implementation EMViewModel

static EMViewModel *instance;

+ (EMViewModel *)sharedInstance {
	@synchronized(self) {
		if (instance == nil) {
			instance = [[EMViewModel alloc] init];
		}
	}
	
	return instance;
}

+ (void)resetInstance {
    instance = nil;
}

- (instancetype)init {
	if (self = [super init]) {
        self.routesList = [NSMutableArray array];
	}
	return self;
}

-(NSMutableArray *)routesList {
    
    if (!_routesList) {
        _routesList = [NSMutableArray array];
    }
    return _routesList;
}

@end

@implementation RouteDetails

-(NSMutableArray *)routeStations {
    
    if (!_routeStations) {
        _routeStations = [NSMutableArray array];
    }
    return _routeStations;
}

@end
